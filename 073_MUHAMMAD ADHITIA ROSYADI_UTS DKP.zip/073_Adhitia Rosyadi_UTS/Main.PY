# Program Monitoring Error terhadap Setpoint
# Kelompok D - Kontrol

# Setpoint yang ditentukan
setpoint = 50

# 15 data inti dan 5 data tambahan
data_output = [
    50, 49, 47, 45, 43, 
    52, 54, 57, 51, 48,
    46, 44, 53, 55, 42, 
    52, 53, 55, 56, 60
]

# Function 1: Menghitung error absolut
def hitung_error(setpoint, output):
    error = abs(setpoint - output)
    return error

# Function 2: Menentukan status berdasarkan error
def status_error(error):
    if error <= 2:
        return "STABIL"
    elif error <= 5:
        return "WARNING"
    else:
        return "TIDAK STABIL"

# Function 3: Menghitung jumlah setiap kategori
def hitung_kategori(data):
    jumlah = {
        "STABIL": 0,
        "WARNING": 0,
        "TIDAK STABIL": 0
    }

    for error in data:
        status = status_error(error)
        jumlah[status] += 1

    return jumlah

# Function 4: Menghitung rata-rata error
def rata_rata(data):
    return sum(data) / len(data)

# Menampilkan hasil setiap data
print("=" * 65)
print("       MONITORING ERROR TERHADAP SETPOINT")
print("=" * 65)

print(f"{'No':<5}{'Output':<12}{'Error':<12}{'Status'}")
print("-" * 65)

data_error = []

for nomor, output in enumerate(data_output, start=1):
    error = hitung_error(setpoint, output)
    status = status_error(error)

    data_error.append(error)

    print(f"{nomor:<5}{output:<12}{error:<12}{status}")

# Menghitung ringkasan akhir
kategori = hitung_kategori(data_error)
rata = rata_rata(data_error)
maksimum = max(data_error)
minimum = min(data_error)

print("=" * 65)
print("RINGKASAN AKHIR")
print("=" * 65)

print("Setpoint             :", setpoint)
print("Total data           :", len(data_output))
print("Jumlah STABIL        :", kategori["STABIL"])
print("Jumlah WARNING       :", kategori["WARNING"])
print("Jumlah TIDAK STABIL  :", kategori["TIDAK STABIL"])
print(f"Rata-rata error      : {rata:.2f}")
print("Maksimum error       :", maksimum)
print("Minimum error        :", minimum)

print("=" * 65)

print("\nPENGUJIAN PROGRAM")

data_uji = [
    (50, 49, "STABIL"),
    (50, 48, "STABIL"),
    (50, 47, "WARNING"),
    (50, 46, "WARNING"),
    (50, 45, "WARNING"),
    (50, 44, "TIDAK STABIL"),
    (50, 50, "STABIL"),
    (50, 60, "TIDAK STABIL")
]

print("=" * 65)
print(f"{'No':<5}{'Setpoint':<10}{'Output':<9}{'Error':<8}{'Expected':<15}{'Hasil'}")
print("-" * 65)

for nomor, (sp, out, expected) in enumerate(data_uji, start=1):
    error = hitung_error(sp, out)
    status = status_error(error)
    hasil = "PASS" if status == expected else "FAIL"

    print(f"{nomor:<5}{sp:<10}{out:<9}{error:<8}{expected:<15}{hasil}")

print("=" * 65)
